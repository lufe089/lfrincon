#include <stdio.h>

//Reserva el espacio para las filas y las columnas de la matriz
cambiarElTipoPorElStruct ** reservarMemoriaMatriz(int fil, int col); 

// LLena la matriz con números consecutivos desde el 10 hasta que se acaben los espacios de la matriz
void llenarMatriz(cambiarxElTipoPorElStruct ** pMatriz , int fil, int col); 

// Muestra la matriz 
void mostrarMatriz(cambiarxElTipoPorElStruct ** pMatriz , int fil, int col); 

//Completar con las que faltan